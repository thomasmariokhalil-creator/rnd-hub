## Packages
date-fns | Formatting dates for announcements and events
framer-motion | Smooth page transitions and card animations
embla-carousel-react | For the featured content carousel

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
